import Titled from "../misc/Titled";

function StudentFacing() {
    return (
        <Titled title="Checkout">
            <></>
        </Titled>
    );
}

export default StudentFacing;
