import Titled from "../misc/Titled";

function AdminFacing() {
    return (
        <Titled title="Admin Panel">
            <></>
        </Titled>
    );
}

export default AdminFacing;
