function TagsView() {
    return (
        <></>
    );
}

export default TagsView;
