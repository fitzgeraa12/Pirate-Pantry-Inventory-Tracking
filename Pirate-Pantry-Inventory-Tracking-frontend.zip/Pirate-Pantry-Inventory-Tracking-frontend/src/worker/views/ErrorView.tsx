function ErrorView() {
    return (
        <div style={{ color: "white" }}>UNKNOWN VIEW</div>
    );
}

export default ErrorView;
