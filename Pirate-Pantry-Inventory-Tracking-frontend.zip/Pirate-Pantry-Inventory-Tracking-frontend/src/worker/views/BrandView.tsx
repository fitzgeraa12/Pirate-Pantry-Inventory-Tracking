function BrandView() {
    return (
        <></>
    );
}

export default BrandView;
