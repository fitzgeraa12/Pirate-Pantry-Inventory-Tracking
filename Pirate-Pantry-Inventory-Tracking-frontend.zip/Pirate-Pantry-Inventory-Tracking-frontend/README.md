# Pirate Pantry Frontend

## How to host
1. Install npm (Node Package Manager)
2. Navigate to the project directory
3. Run 'npm install' to install required packages
4. Run 'npm run dev' to host locally
